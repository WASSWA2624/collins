# AI Vent Backend

Express + Prisma backend foundation for the AI Vent ventilation admission, tracking, review, and dataset governance app.

## Setup

Use Node.js 20 or newer. The `package.json` `engines` field documents this baseline without adding a hard runtime gate.

```bash
npm install
npm run prisma:generate
npm run prisma:migrate
npm run prisma:seed
npm run dev
```

Configure `.env` before starting the backend. The file contains production and development blocks; keep one block uncommented and comment the other.

Local development admin login:

```txt
Email: admin@admin.com
Password: Admin
```

Local development clinician login:

```txt
Email: clinician@clinician.com
Password: Clinician
```

Default API namespace:

```txt
/api/v1
```

Health check:

```txt
GET /api/v1/health
```

Local LAN access:

```txt
HOST=0.0.0.0
```

The development default binds the backend to all network interfaces so Expo clients on the same Wi-Fi/LAN can reach `http://<computer-lan-ip>:3000`.

Training/help content:

```txt
GET /api/v1/training-help
```

`npm install`, `npm run dev`, `npm start`, and `npm test` run Prisma Client generation first. Generation does not require a live MySQL connection, but runtime startup requires `DATABASE_URL` in `.env`. The backend starts independently from the frontend, Expo, and clinical dataset assets.

Database setup for a clean local MySQL database:

```bash
npm ci
npm run prisma:generate
npm run prisma:migrate
npm run prisma:seed
npm test
```

The seed command adds local development platform-admin and clinician users, a verified development facility for those users, a disabled development reference-seed user, and verified MVP reference/evidence ranges. It does not seed patients, admissions, raw notes, demo cases, or approved training datasets.

## Safety position

This backend supports documentation, calculations, validation, audit, review, and governance. It must not autonomously diagnose, prescribe, intubate, extubate, or set ventilator values.
